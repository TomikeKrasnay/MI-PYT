from .cli import cli
from .web import app

__all__ = ['cli']
