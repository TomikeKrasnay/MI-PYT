.. labelord documentation master file, created by
   sphinx-quickstart on Sat Dec  2 19:36:07 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to labelord's documentation!
====================================

Introduction
-------------

Labelord is a application which manage yout GitHub repositories. Via this Python app you can easier get list all repositories or labels and you can delete, add or update multiple repositories labels. You have two option manage your GitHub via CLI or via Flask web interface.

For more information, please check the sections below.

User's guide
-------------
.. toctree::
   :maxdepth: 2
   
   installation
   tutorial
   labelord
   examples
   license
